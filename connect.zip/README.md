# Connect
Connect is a social network application written in Laravel(v7.11.0).

## Features
- create posts
- like, comment, share and save posts
- friendship features
- follow and block features
- real time notifications and events
- browse users, followers and friends
- highly secure authentication, authorizations and validations
- real time messaging
