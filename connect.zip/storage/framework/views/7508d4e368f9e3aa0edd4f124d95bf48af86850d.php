<?php $__env->startSection("link-to-$type"); ?>
<?php echo e($class); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="col-12 col-md-6 feeds">
</div>
  <?php echo $__env->make('post.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/javascript">
function showFeeds(page=0){

  if(page>0)
    document.querySelector("#load-more-posts").remove();

  let feeds_container=document.querySelector('.feeds');

  fetch('<?php echo e($url); ?>/'+page).then(response=>{
    if(response.ok)
     return response.json();
    throw new Error();
  }).then(feeds=>{

    if(page<1 && feeds.length==0)
    {

      <?php if($type=='feeds'): ?>

      feeds_container.innerHTML=`
      <div class="d-flex vh-100">
      <p class="text-center text-muted align-self-center w-100" style="font-size:2em">
        Start follow <a href="<?php echo e(url('/users')); ?>">users</a> to see their posts
      </p>
      </div>`;

      <?php elseif($type=='privates'): ?>

      feeds_container.innerHTML=`
      <div class="d-flex vh-100">
      <p class="text-center text-muted align-self-center w-100" style="font-size:2em">
        No private posts</p>
      </div>`;

      <?php else: ?>

      feeds_container.innerHTML=`
      <div class="d-flex vh-100">
      <p class="text-center text-muted align-self-center w-100" style="font-size:2em">
        No favorite posts</p>
      </div>`;

      <?php endif; ?>

      return false;
    }
    feeds.forEach(function(feed){

      let divfeed=document.createElement('div');
      divfeed.id=`feed_${feed.id}`;
      divfeed.append(renderFeed(feed));
      feeds_container.append(divfeed);

    });

    if(feeds.length==10)
      feeds_container.append(createLoadMore(page+1));
});

}

function createLoadMore(page)
{
  let wrap=document.createElement('p');
  wrap.className="text-center";
  wrap.id="load-more-posts";
  wrap.innerHTML=`<button class="btn btn-light" onclick="showFeeds(${page})">Load more</button>`;

  return wrap;
}

showFeeds();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/menu/feeds.blade.php ENDPATH**/ ?>