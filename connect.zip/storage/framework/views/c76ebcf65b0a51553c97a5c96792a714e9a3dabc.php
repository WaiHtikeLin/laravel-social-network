<div class="col-1 pr-0">
    <?php if(isset($image)): ?>
      <img src="<?php echo e(asset("storage/profile_pics/$profile_pic")); ?>" alt=""
      style="height:2em;width:2em" class="rounded-circle mr-0">

    <?php endif; ?>

  </div>
  <div class="col-11 clearfix pl-0">


    <div class="d-inline-block <?php if(isset($me)): ?> float-right <?php endif; ?>" style="max-width:20em">

    <p class=" text-break px-5 clean-white mb-0 mt-3 shadow rounded-pill" id="msg_${msg.id}" <?php if(isset($me)): ?> data-toggle="collapse"
    data-target="#msg-action-${msg.id}" <?php endif; ?>>
      ${msg.message}
    </p>
    <p class="text-right mb-0 text-muted" style="font-size:0.5em">
      <?php if(isset($me)): ?>
      <span class="send_status">${msg.seen}</span>&nbsp;&nbsp;
      <?php endif; ?>

      ${msg.created_at}</p>

    <?php if(isset($me)): ?>
    <div class="collapse" id="msg-action-${msg.id}">
      <a href="#edit-msg-modal" class="mr-2" data-toggle="modal"
      data-msg-id="${msg.id}" onclick="getMsgToEdit(this)">Edit</a>
      <a href="#" onclick="deleteMsg(this)" data-msg-id="${msg.id}">Delete</a>
    </div>
    <?php endif; ?>

    </div>


  </div>
<?php /**PATH /var/www/html/connect/resources/views/chat/msg-row.blade.php ENDPATH**/ ?>