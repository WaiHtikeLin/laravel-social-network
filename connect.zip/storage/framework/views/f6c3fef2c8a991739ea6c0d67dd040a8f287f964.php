<?php $__env->startSection('main'); ?>

<div class="col-12 col-md-6">
  <h3>Followers</h3>
  <div class="clean-white h-100 pl-3 pt-3">
    <?php $__currentLoopData = $followers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><a href="<?php echo e(url("/user/profile/".$follower->id)); ?>">
        <img src="<?php echo e(asset('/storage/profile_pics/'.$follower->pics[0]->name)); ?>" alt="" class="rounded-circle mr-2"
        style="height:3em;width:3em">
          <strong><?php echo e($follower->name); ?></strong>

      </a>
    </p>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/user/followers.blade.php ENDPATH**/ ?>