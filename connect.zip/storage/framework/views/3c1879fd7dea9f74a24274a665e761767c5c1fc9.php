<?php $__env->startSection('main'); ?>
<form class="" action="<?php echo e(url('')); ?>/update/post/<?php echo e($post->id); ?>" method="post">
  <?php echo csrf_field(); ?>
  <?php echo method_field('patch'); ?>
  <textarea name="texts" rows="8" cols="80"><?php echo e($post->texts); ?></textarea>

  <select class="" name="privacy">
    <option value="friend">Friend</option>
    <option value="public">Public</option>
  </select>

  <input type="submit" name="" value="OK">
</form>

<form action="/delete/post/<?php echo e($post->id); ?>" method="post">
  <?php echo csrf_field(); ?>
  <?php echo method_field('delete'); ?>
  <input type="submit" name="delete" value="Delete">

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/post/edit.blade.php ENDPATH**/ ?>