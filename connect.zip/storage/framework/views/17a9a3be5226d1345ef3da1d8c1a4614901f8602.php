<?php $__env->startSection('main'); ?>
<script type="text/javascript">
  let id=<?php echo e(Auth::id()); ?>;
  Echo.private('App.User.'+id).notification((notification) => {
        alert(notification.name);
    });
</script>
<p>Hello</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/user/test.blade.php ENDPATH**/ ?>