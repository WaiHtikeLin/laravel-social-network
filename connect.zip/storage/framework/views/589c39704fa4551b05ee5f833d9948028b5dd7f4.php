<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column align-items-center">
  <p>Please wait</p>
  <div class="spinner-border spinner-border-sm" role="status">
    <span class="sr-only">Loading...</span>
  </div>
</div>

<script type="text/javascript">

const data={
  'email' : 'guest@gmail.com',
  'password' : 'guest12345'
};

fetch('<?php echo e(route('login')); ?>',{
  method: 'POST',
  headers:{
    'Content-Type': 'application/json;charset=utf-8',
    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content

  },

  body: JSON.stringify(data)
}).then(response=>{
  if(response.ok)
    location.href='<?php echo e(url('/home')); ?>';
});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/auth/autologin.blade.php ENDPATH**/ ?>