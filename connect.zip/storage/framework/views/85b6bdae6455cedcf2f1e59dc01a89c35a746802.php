<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>User can't be available!</h1>
  </body>
</html>
<?php /**PATH /var/www/html/connect/resources/views/user/errors/profileerror.blade.php ENDPATH**/ ?>