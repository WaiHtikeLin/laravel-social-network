<nav class="nav flex-column w-75">
   <a href="<?php echo e(url('')); ?>/myprofile" class="nav-link">
     <img src="<?php echo e(asset("storage/profile_pics/")); ?>/<?php echo e(Auth::user()->getProfilePic()); ?>" alt="" style="height:3em;width:3em" class="rounded-circle mr-2">
    <?php echo e(Auth::user()->name); ?></a>
  <a class="nav-link <?php echo $__env->yieldContent('link-to-profile'); ?> side-item" href="<?php echo e(url('')); ?>/myprofile"><img src="<?php echo e(asset('/img/profile.png')); ?>" alt="" class="side-menu">Profile</a>
   <a class="nav-link side-item" data-toggle="modal" href="#newPost">
     <img src="<?php echo e(asset('/img/plus.png')); ?>" alt="" class="side-menu">
     New Post</a>
   <a class="nav-link <?php echo $__env->yieldContent('link-to-privates'); ?> side-item" href="<?php echo e(url('/posts/privates')); ?>">
     <img src="<?php echo e(asset('/img/lock.png')); ?>" alt="" class="side-menu">
     Private Posts</a>
  <a class="nav-link <?php echo $__env->yieldContent('link-to-favorites'); ?> side-item" href="<?php echo e(url('/posts/favorites')); ?>"><img src="<?php echo e(asset('/img/heart.png')); ?>" alt="" class="side-menu">Favorites</a>
  <a class="nav-link <?php echo $__env->yieldContent('link-to-settings'); ?> side-item" href="<?php echo e(url('/settings')); ?>"><img src="<?php echo e(asset('/img/settings.png')); ?>" alt="" class="side-menu">Settings</a>

   <a class="nav-link side-item" href="<?php echo e(route('logout')); ?>"
      onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();"><img src="<?php echo e(asset('/img/logout.png')); ?>" alt="" class="side-menu">Logout</a>

  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
  </form>

</nav>

  <p style="font-size:0.8em" class="mt-5 text-center">
    <a href="<?php echo e(url('/privacy')); ?>" class="<?php echo $__env->yieldContent('link-to-privacy'); ?>">Data Privacy</a>
    &nbsp;<a href="<?php echo e(url('/terms')); ?>" class="<?php echo $__env->yieldContent('link-to-terms'); ?>">Terms</a>
    &nbsp; <a href="<?php echo e(url('/cookies')); ?>" class="<?php echo $__env->yieldContent('link-to-cookies'); ?>">Cookies</a>
    &nbsp;<a href="<?php echo e(url('/about')); ?>" class="<?php echo $__env->yieldContent('link-to-about'); ?>">About</a>
    <br>
    <a href="<?php echo e(url('/user/profile/1')); ?>" class="<?php echo $__env->yieldContent('link-to-contact'); ?>">Contact</a>
    &nbsp; <a href="<?php echo e(url('/help')); ?>" class="<?php echo $__env->yieldContent('link-to-help'); ?>">Help</a> </p>

  <p class="text-center">Connect &#169;2020</p>
<?php /**PATH /var/www/html/connect/resources/views/components/side-nav.blade.php ENDPATH**/ ?>