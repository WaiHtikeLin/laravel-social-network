<?php $__env->startSection('link-to-help'); ?>
side-nav-active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="col-12 col-md-6 clean-white pt-2">

  <?php if(session('status')): ?>

  <div class="alert alert-success alert-dismissible fade show" role="alert">
  <?php echo e(session('status')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>

  <?php endif; ?>

  <form action="<?php echo e(url('/add/question')); ?>" method="post">

    <?php echo csrf_field(); ?>
    <p>
      Ask question about something you want to know with our app, we will answer shortly:
    </p>
    <textarea name="question" class="form-control mb-3" placeholder="Ask question..." required></textarea>

    <p class="text-center">
      <input type="submit" name="" value="Send" class="btn btn-light">
    </p>
  </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/app/help.blade.php ENDPATH**/ ?>