<?php $__env->startSection('link-to-profile'); ?>
side-nav-active
<?php $__env->stopSection(); ?>

<?php if($user->id==1): ?>
  <?php $__env->startSection('link-to-contact'); ?>
  side-nav-active
  <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>

<div class="col-12 col-md-6">
  <div class="d-flex flex-column mb-5">

    <img src="<?php echo e(asset("storage/profile_pics/$profile_pic")); ?>"
    class="rounded-circle mb-2 align-self-center" alt=""
    style="height:5em;width:5em">

    <?php if(isset($mine)): ?>
    <p class="mb-2 align-self-center">

        <a href="#change-profile-pic" data-toggle="collapse" aria-expanded="false">Change</a>
    </p>

    <div class="collapse align-self-center mb-2" id="change-profile-pic">
      <form action="<?php echo e('/change/profile_pic'); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <input type="file" name="profile_pic" id="profile_pic"required>
        <input type="submit" value="Change">
      </form>
    </div>

    <?php endif; ?>

    <p class="mb-2 align-self-center">
      <strong><?php echo e($user->name); ?></strong>
      <?php if(isset($mine)): ?>
        <a href="#edit-name" class="ml-2" data-toggle="collapse" aria-expanded="false">Edit</a>
      <?php endif; ?></p>

    <?php if(isset($mine)): ?>
    <div class="collapse align-self-center" id="edit-name">

      <form action="<?php echo e(url('/change/name')); ?>" method="post">

        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <input type="text" name="name" placeholder="Enter new name" required>
        <button type="submit" name="button">Update</button>
      </form>

    </div>
    <?php endif; ?>



    <?php if($about && (($me->canViewInfo($about['privacy'],$info->user_id) || isset($mine)))): ?>
    <p class="mb-2 align-self-center" id="about-info"><?php echo e($about['name']); ?></p>
    <?php endif; ?>



    <?php if(empty($mine)): ?>
    <div class="btn-group align-self-center" role="group" aria-label="profile options">
      <div id="friendship">
        <?php echo $__env->make('user.friendshipstatus',['status'=>$friendship_status], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>

      <div id="follow">
        <?php echo $__env->make('user.followstatus',['status'=>$follow_status], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>


      <button type="button" name="button" class="btn btn-primary mr-1 rounded-pill" onclick="location.href='<?php echo e(url('')); ?>/chat/to/<?php echo e($user->id); ?>';">Message</button>
      <button type="button" name="button" class="btn btn-danger mr-1 rounded-pill" onclick="block()">Block</button>
    </div>



    <?php if($friendship_status=='Accept'): ?>

    <div class="align-self-center" id="friend-request-in-profile">
      <p class="text-center"><?php echo e($user->name); ?> sent you a friend request</p>
      <p class="text-center">
        <div class="btn-group" role="group" aria-label="request options">
          <button type="button" name="button" class="btn btn-success mr-1 rounded-pill" onclick="acceptFriend()">Accept</button>
          <button type="button" name="button" class="btn btn-danger mr-1 rounded-pill" onclick="rejectFriend()">Reject</button>
        </div>
      </p>

    </div>

    <?php endif; ?>
    <?php endif; ?>
  </div>



  <p>Overview</p>

<div class="about clean-white px-2 mb-2">

  <?php if($edu && (($me->canViewInfo($edu['privacy'],$info->user_id) || isset($mine)))): ?>
  <p><img src="<?php echo e(asset("img/book.png")); ?>" alt="" class="info-icon mr-2"><?php echo e($edu['name']); ?></p>
  <?php endif; ?>

  <?php if($work && (($me->canViewInfo($work['privacy'],$info->user_id) || isset($mine)))): ?>
  <p><img src="<?php echo e(asset("img/work.png")); ?>" alt="" class="info-icon mr-2"><?php echo e($work['name']); ?></p>
  <?php endif; ?>

  <?php if($address && (($me->canViewInfo($address['privacy'],$info->user_id) || isset($mine)))): ?>
  <p><img src="<?php echo e(asset("img/location.png")); ?>" alt="" class="info-icon mr-2"><?php echo e($address['name']); ?></p>
  <?php endif; ?>

  <?php if($email && (($me->canViewInfo($email['privacy'],$info->user_id) || isset($mine)))): ?>
  <p><img src="<?php echo e(asset("img/email.png")); ?>" alt="" class="info-icon mr-2"><?php echo e($email['name']); ?></p>
  <?php endif; ?>

  <?php if($site && (($me->canViewInfo($site['privacy'],$info->user_id) || isset($mine)))): ?>
  <p><img src="<?php echo e(asset("img/global.png")); ?>" alt="" class="info-icon mr-2"><?php echo e($site['name']); ?></p>
  <?php endif; ?>

  <?php if($phone && (($me->canViewInfo($phone['privacy'],$info->user_id) || isset($mine)))): ?>
  <p><img src="<?php echo e(asset("img/phone.png")); ?>" alt="" class="info-icon mr-2"><?php echo e($phone['name']); ?></p>
  <?php endif; ?>

  <?php if($me->canViewInfo($settings->friends_privacy,$settings->user_id) || isset($mine)): ?>
    <?php if($user->friends_count || $user->accepted_friends_count): ?>
    <p><a href="<?php echo e(url("/users/$user->id/friends")); ?>"><?php echo e($user->friends_count+$user->accepted_friends_count); ?> friend(s)</a></p>
    <?php endif; ?>
  <?php endif; ?>

  <?php if($me->canViewInfo($settings->followers_privacy,$settings->user_id) || isset($mine)): ?>
    <?php if($user->followers_count): ?>
    <p><a href="<?php echo e(url("/users/$user->id/followers")); ?>"><?php echo e($user->followers_count); ?> follower(s)</a></p>
    <?php endif; ?>
  <?php endif; ?>

  <?php if($me->canViewInfo($settings->following_privacy,$settings->user_id) || isset($mine)): ?>
    <?php if($user->following_count): ?>
    <p><a href="<?php echo e(url("users/$user->id/following")); ?>"><?php echo e($user->following_count); ?> following</a></p>
    <?php endif; ?>
  <?php endif; ?>

  <?php if(isset($mine)): ?>
    <?php if($user->sentRequests_count): ?>
      <p><a href="<?php echo e(url('sentrequests')); ?>"><?php echo e($user->sentRequests_count); ?> sent request(s)</a></p>
    <?php endif; ?>
  <?php endif; ?>

  <div style="height:50px" class="d-flex justify-content-center align-items-center">
    <a data-toggle="collapse" href="#all_informations"
    aria-expanded="false" aria-controls="all informations">More</a>
  </div>
</div>

<?php if(isset($mine)): ?>
<div class="collapse" id="all_informations">



  <p class="p-2">About
    <a href="#add-about" class="ml-2 <?php if($info->about): ?> d-none <?php endif; ?>" data-toggle="collapse" aria-expanded="false"
    aria-controls="add about">Add</a>

  </p>

  <div class="collapse" id="add-about">
    <?php echo $__env->make('user.addinfo',['title'=>'about','wrap'=>'#about-content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>

<?php if($info->about): ?>
<div class="clean-white mb-2 p-2">


  <div id="about-content">

    <div>
      <p><?php echo e($info->about['name']); ?><img src="<?php echo e(asset('img')); ?>/<?php echo e($info->about['privacy']); ?>.png" alt="" class="ml-2 info-privacy">
      <a href="#edit-about" class="mx-2" data-toggle="collapse" aria-expanded="false">Edit</a>
      <a href="#" class="ml-2" onclick="deleteInfo(this)" data-name="about" data-id="">Delete</a>
    </p>
      <div class="collapse" id="edit-about">
        <?php echo $__env->make('user.addinfo',['edit'=>true,'name'=>$info->about['name'],'privacy'=>$info->about['privacy'],'id'=>'','title'=>'about'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>



</div>



</div>
<?php endif; ?>



  <p>
    Education
    <a href="#add-edu" class="ml-2 mr-2" data-toggle="collapse" aria-expanded="false" aria-controls="add edu">Add</a>

  </p>

  <div class="collapse" id="add-edu">
    <?php echo $__env->make('user.addinfo',['title'=>'education','wrap'=>'#edu-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>





  <div class="clean-white mb-2">


    <ul id="edu-list">
  <?php if($info->education): ?>

    <?php $__currentLoopData = $info->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div>
      <li id="education_<?php echo e($id); ?>"><?php echo e($edu['name']); ?>

        <img src="<?php echo e(asset('img')); ?>/<?php echo e($edu['privacy']); ?>.png" alt="" class="ml-2 info-privacy">
        <a href="#edit_education_<?php echo e($id); ?>" class="mx-2" data-toggle="collapse" aria-expanded="false">Edit</a>
        <a href="#" class="ml-2" onclick="deleteInfo(this)" data-name="education" data-id=<?php echo e($id); ?>>Delete</a>
      </li>

      <div class="collapse" id="edit_education_<?php echo e($id); ?>">
        <?php echo $__env->make('user.addinfo',['edit'=>true,'name'=>$edu['name'],'privacy'=>$edu['privacy'],'title'=>'education'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
  </ul>
</div>



<p>
  Work
  <a href="#add-work" class="ml-2" data-toggle="collapse" aria-expanded="false" aria-controls="add work">Add</a>
</p>

<div class="collapse" id="add-work">
  <?php echo $__env->make('user.addinfo',['title'=>'work','wrap'=>'#work-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

  <div class="clean-white mb-2">

    <ul id="work-list">

<?php if($info->work): ?>
    <?php $__currentLoopData = $info->work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div>
      <li id="work_<?php echo e($id); ?>"><?php echo e($w['name']); ?>


        <img src="<?php echo e(asset('img')); ?>/<?php echo e($w['privacy']); ?>.png" alt="" class="ml-2 info-privacy">
        <a href="#edit_work_<?php echo e($id); ?>" class="mx-2" data-toggle="collapse" aria-expanded="false">Edit</a>
        <a href="#" class="ml-2" onclick="deleteInfo(this)" data-name="work" data-id=<?php echo e($id); ?>>Delete</a>
      </li>

      <div class="collapse" id="edit_work_<?php echo e($id); ?>">
        <?php echo $__env->make('user.addinfo',['edit'=>true,'name'=>$w['name'],'privacy'=>$w['privacy'],'title'=>'work'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  </ul>
</div>



<p>
  Address
  <a href="#add-address" class="ml-2" data-toggle="collapse" aria-expanded="false" aria-controls="add address">Add</a>
</p>

<div class="collapse" id="add-address">
  <?php echo $__env->make('user.addinfo',['title'=>'address','wrap'=>'#address-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

  <div class="clean-white mb-2">

    <ul id="address-list">
<?php if($info->address): ?>

    <?php $__currentLoopData = $info->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div>
        <li id="address_<?php echo e($id); ?>"><?php echo e($a['name']); ?>

        <img src="<?php echo e(asset('img')); ?>/<?php echo e($a['privacy']); ?>.png" alt="" class="ml-2 info-privacy">
        <a href="#edit_address_<?php echo e($id); ?>" class="mx-2" data-toggle="collapse" aria-expanded="false">Edit</a>
        <a href="#" class="ml-2" onclick="deleteInfo(this)" data-name="address" data-id=<?php echo e($id); ?>>Delete</a>
      </li>

      <div class="collapse" id="edit_address_<?php echo e($id); ?>">
        <?php echo $__env->make('user.addinfo',['edit'=>true,'name'=>$a['name'],'privacy'=>$a['privacy'],'title'=>'address'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      </div>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </ul>
  </div>



<p>
  Email
  <a href="#add-email" class="ml-2" data-toggle="collapse" aria-expanded="false" aria-controls="add email">Add</a>
</p>

<div class="collapse" id="add-email">
  <?php echo $__env->make('user.addinfo' ,['title'=>'email','wrap'=>'#email-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

  <div class="clean-white mb-2">

    <ul id="email-list">

<?php if($info->emails): ?>
    <?php $__currentLoopData = $info->emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div>
      <li id="email_<?php echo e($id); ?>"><?php echo e($e['name']); ?>


        <img src="<?php echo e(asset('img')); ?>/<?php echo e($e['privacy']); ?>.png" alt="" class="ml-2 info-privacy">
        <a href="#edit_email_<?php echo e($id); ?>" class="mx-2" data-toggle="collapse" aria-expanded="false">Edit</a>
        <a href="#" class="ml-2" onclick="deleteInfo(this)" data-name="emails" data-id=<?php echo e($id); ?>>Delete</a>
      </li>

      <div class="collapse" id="edit_email_<?php echo e($id); ?>">
        <?php echo $__env->make('user.addinfo',['edit'=>true,'name'=>$e['name'],'privacy'=>$e['privacy'],'title'=>'email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
  </ul>
</div>


<p>
  Website
  <a href="#add-site" class="ml-2" data-toggle="collapse" aria-expanded="false" aria-controls="add site">Add</a>
</p>

<div class="collapse" id="add-site">
  <?php echo $__env->make('user.addinfo',['title'=>'site','wrap'=>'#site-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

  <div class="clean-white mb-2">

    <ul id="site-list">

<?php if($info->websites): ?>
    <?php $__currentLoopData = $info->websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
      <li id="site_<?php echo e($id); ?>"><?php echo e($w['name']); ?>

        <img src="<?php echo e(asset('img')); ?>/<?php echo e($w['privacy']); ?>.png" alt="" class="ml-2 info-privacy">
        <a href="#edit_site_<?php echo e($id); ?>" class="mx-2" data-toggle="collapse" aria-expanded="false">Edit</a>
        <a href="#" class="ml-2" onclick="deleteInfo(this)" data-name="websites" data-id=<?php echo e($id); ?>>Delete</a>
      </li>

      <div class="collapse" id="edit_site_<?php echo e($id); ?>">
        <?php echo $__env->make('user.addinfo',['edit'=>true,'name'=>$w['name'],'privacy'=>$w['privacy'],'title'=>'site'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  </ul>
</div>



<p>
  Phone
  <a href="#add-phone" class="ml-2" data-toggle="collapse" aria-expanded="false" aria-controls="add phone">Add</a>
</p>

<div class="collapse" id="add-phone">
  <?php echo $__env->make('user.addinfo',['title'=>'phone','wrap'=>'#phone-list'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


  <div class="clean-white mb-2">

    <ul id="phone-list">
<?php if($info->ph_numbers): ?>

    <?php $__currentLoopData = $info->ph_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div>
      <li id="phone_<?php echo e($id); ?>"><?php echo e($p['name']); ?>


        <img src="<?php echo e(asset('img')); ?>/<?php echo e($p['privacy']); ?>.png" alt="" class="ml-2 info-privacy">
        <a href="#edit_phone_<?php echo e($id); ?>" class="mx-2" data-toggle="collapse" aria-expanded="false">Edit</a>
        <a href="#" class="ml-2" onclick="deleteInfo(this)" data-name="ph_numbers" data-id=<?php echo e($id); ?>>Delete</a>
      </li>

      <div class="collapse" id="edit_phone_<?php echo e($id); ?>">
        <?php echo $__env->make('user.addinfo',['edit'=>true,'name'=>$p['name'],'privacy'=>$p['privacy'],'title'=>'phone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
  </ul>
  </div>


<p class="p-2">Bio
  <a href="#add-bio" class="ml-2 <?php if($info->bio): ?> d-none <?php endif; ?>" data-toggle="collapse" aria-expanded="false" aria-controls="add bio">Add</a>
</p>

<div class="collapse" id="add-bio">
  <?php echo $__env->make('user.addinfo',['title'=>'bio','wrap'=>'#bio-content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>




  <div class="clean-white mb-2">


<div id="bio-content">

  <?php if($info->bio): ?>
  <div>
    <p><?php echo e($info->bio['name']); ?>

    <img src="<?php echo e(asset('img')); ?>/<?php echo e($info->bio['privacy']); ?>.png" alt="" class="ml-2 info-privacy">
    <a href="#edit_bio_<?php echo e($id); ?>" class="mx-2" data-toggle="collapse" aria-expanded="false">Edit</a>
    <a href="#" class="ml-2" onclick="deleteInfo(this)" data-name="bio" data-id="">Delete</a>
  </p>

    <div class="collapse" id="edit_bio_<?php echo e($id); ?>">
      <?php echo $__env->make('user.addinfo',['edit'=>true,'name'=>$info->bio['name'],'privacy'=>$info->bio['privacy'],'id'=>'','title'=>'bio'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>


  <?php endif; ?>
</div>

  </div>




</div>

<?php else: ?>
<div class="collapse" id="all_informations">

  <?php if($info->education): ?>
  <div class="clean-white mb-2">
    <p style="border-bottom:2px solid green" class="p-2">Education</p>
    <ul>


    <?php $__currentLoopData = $info->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($me->canViewInfo($edu['privacy'],$info->user_id)): ?>
      <li><?php echo e($edu['name']); ?></li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php endif; ?>

  <?php if($info->work): ?>
  <div class="clean-white mb-2">
    <p style="border-bottom:2px solid green" class="p-2">Work</p>
    <ul>


    <?php $__currentLoopData = $info->work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($me->canViewInfo($w['privacy'],$info->user_id)): ?>
      <li><?php echo e($w['name']); ?></li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php endif; ?>

<?php if($info->address): ?>
  <div class="clean-white mb-2">
    <p style="border-bottom:2px solid green" class="p-2">Address</p>
    <ul>


    <?php $__currentLoopData = $info->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($me->canViewInfo($a['privacy'],$info->user_id)): ?>
      <li><?php echo e($a['name']); ?></li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  </div>
<?php endif; ?>

<?php if($info->emails): ?>
  <div class="clean-white mb-2">
    <p style="border-bottom:2px solid green" class="p-2">Emails</p>
    <ul>


    <?php $__currentLoopData = $info->emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($me->canViewInfo($e['privacy'],$info->user_id)): ?>
      <li><?php echo e($e['name']); ?></li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  </div>
<?php endif; ?>

<?php if($info->websites): ?>
  <div class="clean-white mb-2">
    <p style="border-bottom:2px solid green" class="p-2">Websites</p>
    <ul>


    <?php $__currentLoopData = $info->websites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($me->canViewInfo($w['privacy'],$info->user_id)): ?>
      <li><?php echo e($w['name']); ?></li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php endif; ?>

<?php if($info->ph_numbers): ?>
  <div class="clean-white mb-2">
    <p style="border-bottom:2px solid green" class="p-2">Phone</p>
    <ul>


    <?php $__currentLoopData = $info->ph_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($me->canViewInfo($p['privacy'],$info->user_id)): ?>
      <li><?php echo e($p['name']); ?></li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  </div>
<?php endif; ?>

<?php if($info->bio): ?>
  <div class="clean-white mb-2">
    <p style="border-bottom:2px solid green" class="p-2">Bio</p>

    <?php if($me->canViewInfo($info->bio['privacy'],$info->user_id)): ?>
    <p><?php echo e($info->bio['name']); ?></p>
    <?php endif; ?>

  </ul>
  </div>
<?php endif; ?>
</div>

<?php endif; ?>

<?php echo $__env->make('post.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="feeds">

  </div>
</div>
  <script>




      async function unfriend()
      {
        event.preventDefault();

        let response=await fetch('<?php echo e(url("/unfriend/to/$user->id")); ?>',{
          method: 'DELETE',
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }

        });
        if(response.ok)
        {
          document.querySelector("#friendship").innerHTML=`<?php echo $__env->make('user.friendshipstatus',['status'=>'Add friend'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`;
        }
      }

      async function cancelRequest()
      {
        event.preventDefault();

        let response=await fetch('<?php echo e(url("/cancel/request/to/$user->id")); ?>',{
          method: 'DELETE',
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }

        });
        if(response.ok)
        {
          document.querySelector("#friendship").innerHTML=`<?php echo $__env->make('user.friendshipstatus',['status'=>'Add friend'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`;
        }

      }

      async function addFriend()
      {
        let response=await fetch('<?php echo e(url("/request/to/$user->id")); ?>',{
          method: 'POST',
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }

        });
        if(response.ok)
        { let result=await response.json();
          if(result=='ok')
            document.querySelector("#friendship").innerHTML=`<?php echo $__env->make('user.friendshipstatus',['status'=>'Requested'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`;
        }
      }

      async function acceptFriend()
      {
        let response=await fetch("<?php echo e(url('')); ?>/accept/to/<?php echo e($user->id); ?>",{
          method: 'POST',
          headers:{
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

        if(response.ok)
        {
          document.querySelector("#friend-request-in-profile").remove();
          document.querySelector("#friendship").innerHTML=`<?php echo $__env->make('user.friendshipstatus',['status'=>'Friend'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`;
        }
      }

      async function rejectFriend()
      {
        let response=await fetch("<?php echo e(url('')); ?>/reject/to/<?php echo e($user->id); ?>",{
          method: 'DELETE',
          headers:{
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

        if(response.ok)
        {
          document.querySelector("#friend-request-in-profile").remove();
          document.querySelector("#friendship").innerHTML=`<?php echo $__env->make('user.friendshipstatus',['status'=>'Add friend'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`;
        }
      }

      async function follow()
      {
        let response=await fetch('<?php echo e(url('/follow/to/'.$user->id)); ?>',{
          method: 'POST',
          headers:{
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }

        });

        if(response.ok)
        {
          document.querySelector("#follow").innerHTML=`<?php echo $__env->make('user.followstatus',['status'=>'Following'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`;
        }
      }

      async function cancelFollow()
      {
        let response=await fetch('<?php echo e(url('/cancel/follow/to/'.$user->id)); ?>',{
          method: 'DELETE',
          headers:{
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }

        });

        if(response.ok)
        {
          document.querySelector("#follow").innerHTML=`<?php echo $__env->make('user.followstatus',['status'=>'Follow'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`;
        }
      }


    async function block()
    {
      if(confirm('Are you sure?'))
        location.href='<?php echo e(url('')); ?>/block/to/<?php echo e($user->id); ?>';
    }


    function showFeeds(page=0){

      if(page>0)
        document.querySelector("#load-more-posts").remove();

      let feeds_container=document.querySelector('.feeds');

      fetch('<?php echo e(url("/get/$user->id/posts")); ?>/'+page).then(response=>{
        if(response.ok)
         return response.json();
        throw new Error();
      }).then(feeds=>{

        if(page<1 && feeds.length==0)
        {
          feeds_container.innerHTML=`
          <div class="d-flex vh-100">
          <p class="text-center text-muted align-self-center w-100" style="font-size:2em">No posts</p>
          </div>`;
          return false;
        }

        feeds.forEach(function(feed){

          let divfeed=document.createElement('div');
          divfeed.id=`feed_${feed.id}`;
          divfeed.append(renderFeed(feed));
          feeds_container.append(divfeed);

        });

        if(feeds.length==10)
          feeds_container.append(createLoadMore(page+1));
    });

    }

    function createLoadMore(page)
    {
      let wrap=document.createElement('p');
      wrap.className="text-center";
      wrap.id="load-more-posts";
      wrap.innerHTML=`<button class="btn btn-light" onclick="showFeeds(${page})">Load more</button>`;

      return wrap;
    }

    showFeeds();

    async function addInfo(f,title,wrap)
    { event.preventDefault();
      let response=await fetch('<?php echo e(url('update')); ?>/'+title,{
        method:'POST',
        body: new FormData(f)

      });

      if(response.ok)
      {
        let info=await response.json();

        let w=document.querySelector(wrap);
        let elem=document.createElement('div');
        elem.innerHTML=`<?php echo $__env->make('user.infoitem', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>`;
        w.append(elem);

        if(title=='about' || title=='bio')
        {
          document.querySelector(`a[aria-controls="add ${title}"]`).classList.add('d-none');
          new bootstrap.Collapse(document.querySelector(`#add-${title}`)).hide();

        }

      }



    }

    async function updateInfo(f,title)
    { event.preventDefault();


      let url;
      if(title=='about' || title=='bio')
        url=`/update/${title}`;

      else
      {
        let id=f.dataset.id;
        url=`/update/${title}/${id}`;
      }

      let response=await fetch('<?php echo e(url('')); ?>'+url,{
        method:'POST',
        body: new FormData(f)

      });

      if(response.ok)
      {
        let info=await response.json();

        let wrap=f.parentNode.parentNode;

        wrap.innerHTML=`<div><?php echo $__env->make('user.infoitem', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>`;


      }



    }

    async function deleteInfo(link)
    {
      event.preventDefault();
      let field=link.dataset.name;
      let id=link.dataset.id;

      let response=await fetch(`<?php echo e(url('')); ?>/delete/${field}/${id}`,{
        method:'DELETE',
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }

      });

      if(response.ok)
      {

        link.parentNode.parentNode.remove();
        if(field=='about' || field=='bio')
        document.querySelector(`a[aria-controls="add ${field}"]`).classList.remove('d-none');
      }
    }
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/menu/profile.blade.php ENDPATH**/ ?>