<?php if(isset($address)): ?>

<form class="" action="<?php echo e(url("update/address/$id")); ?>" method="post">
  Country<input type="text" name="country" value="<?php echo e($address['country']); ?>">
  City<input type="text" name="city" value="<?php echo e($address['city']); ?>">
  Detail<input type="text" name="detail" value="<?php echo e($address['detail']); ?>">
  From <input type="date" name="from" value="<?php echo e($address['from']); ?>">
  To <input type="date" name="to" value="<?php echo e($address['to']); ?>">
  <?php echo csrf_field(); ?>
  <input type="submit" name="" value="Save">

</form>

<?php else: ?>

<form class="" action="<?php echo e(url("update/address")); ?>" method="post">
  Country<input type="text" name="country" value="">
  City<input type="text" name="city" value="">
  Detail<input type="text" name="detail" value="">
  From <input type="date" name="from" value="">
  To <input type="date" name="to" value="">
  <?php echo csrf_field(); ?>
  <input type="submit" name="" value="Save">

</form>
<?php /**PATH /var/www/html/connect/resources/views/user/addaddress.blade.php ENDPATH**/ ?>