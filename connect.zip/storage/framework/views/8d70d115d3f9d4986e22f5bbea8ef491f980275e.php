<?php if(isset($edit)): ?>
<form method="post" onsubmit="updateInfo(this,'<?php echo e($title); ?>')" data-id="<?php echo e($id); ?>">
  <?php echo csrf_field(); ?>
<div class="row mb-2">
  <div class="col-7">
    <input class="col-7 form-control rounded-pill mr-2"
    type="text" name="name" placeholder="edit <?php echo e($title); ?>" value="<?php echo e($name); ?>">
  </div>

  <div class="col-3">
    <select class="form-select" name="privacy" aria-label="Choose privacy">
      <option value="<?php echo e($privacy); ?>">Unchanged</option>
      <option value="onlyme">Only me</option>
      <option value="friend">Friends</option>
      <option value="public">Public</option>
    </select>
  </div>

  <input type="submit" name="button" class="col-2 btn btn-success rounded-pill" value="Update">
</div>
</form>

<?php else: ?>

<form class="" method="post" onsubmit="addInfo(this,'<?php echo e($title); ?>','<?php echo e($wrap); ?>')">
  <?php echo csrf_field(); ?>
<div class="row mb-2">
  <div class="col-7">
    <input class="col-7 form-control rounded-pill mr-2"
    type="text" name="name" placeholder="add <?php echo e($title); ?>">
  </div>

  <div class="col-3">
    <select class="form-select" name="privacy" aria-label="Choose privacy">
      <option value="onlyme">Only me</option>
      <option value="friend">Friends</option>
      <option value="public">Public</option>
    </select>
  </div>

  <input type="submit" name="button" class="col-2 btn btn-success rounded-pill" value="Add">
</div>
</form>

<?php endif; ?>
<?php /**PATH /var/www/html/connect/resources/views/user/addinfo.blade.php ENDPATH**/ ?>