<?php if(isset($work)): ?>

<form class="" action="<?php echo e(url("update/work/$id")); ?>" method="post">
  Name<input type="text" name="name" value="<?php echo e($work['name']); ?>">
  Title<input type="text" name="title" value="<?php echo e($work['title']); ?>">
  From <input type="date" name="from" value="<?php echo e($work['from']); ?>">
  To <input type="date" name="to" value="<?php echo e($work['to']); ?>">
  <?php echo csrf_field(); ?>
  <input type="submit" name="" value="Save">

</form>

<?php else: ?>
<form class="" action="<?php echo e(url('update/work')); ?>" method="post">
  Name<input type="text" name="name" value="">
  Title<input type="text" name="title" value="">
  From <input type="date" name="from" value="">
  To <input type="date" name="to" value="">
  <?php echo csrf_field(); ?>
  <input type="submit" name="" value="Save">

</form>

<?php endif; ?>
<?php /**PATH /var/www/html/connect/resources/views/user/addwork.blade.php ENDPATH**/ ?>