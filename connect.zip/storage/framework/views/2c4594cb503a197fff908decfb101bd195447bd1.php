<li id="${info.type}_${info.id}">${info.name}

  <img src="<?php echo e(asset('img')); ?>/${info.privacy}.png" alt="" class="ml-2 info-privacy">
  <a href="#edit_${info.type}_${info.id}" class="mx-2" data-toggle="collapse" aria-expanded="false">Edit</a>
  <a href="#" class="ml-2" onclick="deleteInfo(this)" data-name="${info.field}" data-id=${info.id}>Delete</a>
</li>

<div class="collapse" id="edit_${info.type}_${info.id}">
  <?php echo $__env->make('user.addinfo',['edit'=>true,'name'=>'${info.name}','privacy'=>'${info.privacy}','title'=>'${info.type}','id'=>'${info.id}'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /var/www/html/connect/resources/views/user/infoitem.blade.php ENDPATH**/ ?>