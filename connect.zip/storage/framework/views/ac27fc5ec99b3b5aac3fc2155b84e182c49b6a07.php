<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
          <h3>Terms Of Service</h3>
          <ul>
            <li>We don’t charge you to use Connect or the other products and services covered by these Terms</li>
            <li>We neither sell you data nor analyze your data.</li>
            <li>You give us permission to store your data</li>
          </ul>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/app/terms_of_service.blade.php ENDPATH**/ ?>