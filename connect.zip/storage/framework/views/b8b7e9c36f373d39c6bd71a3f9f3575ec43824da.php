<?php $__env->startSection('main'); ?>

<div class="col-12 col-md-6">
  <h3>Blocked People</h3>
  <div class="clean-white h-100 pl-3 pt-3">
    <?php $__currentLoopData = $blocked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><a href="<?php echo e(url("/user/profile/".$block->id)); ?>">
        <img src="<?php echo e(asset('/storage/profile_pics/'.$block->pics[0]->name)); ?>" alt="" class="rounded-circle mr-2"
        style="height:3em;width:3em">
          <strong><?php echo e($block->name); ?></strong>

      </a>

      <a href='<?php echo e("unblock/to/$block->id"); ?>' class="ml-2">Unblock</a>
    </p>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/user/blocked.blade.php ENDPATH**/ ?>