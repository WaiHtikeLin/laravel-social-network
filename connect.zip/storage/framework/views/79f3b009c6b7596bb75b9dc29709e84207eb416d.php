<?php if(isset($edu)): ?>
<form class="" action="<?php echo e(url("update/education/$id")); ?>" method="post">
  Name<input type="text" name="name" value="<?php echo e($edu['name']); ?>">
  From <input type="date" name="from" value="<?php echo e($edu['from']); ?>">
  To <input type="date" name="to" value="<?php echo e($edu['to']); ?>">
  <?php echo csrf_field(); ?>
  <input type="submit" name="" value="Save">

</form>
<?php else: ?>

<form class="" action="<?php echo e(url("update/education")); ?>" method="post">
  Name<input type="text" name="name" value="<?php echo e(old('name')); ?>">
  From <input type="date" name="from" value="<?php echo e(old('from')); ?>">
  To <input type="date" name="to" value="<?php echo e(old('to')); ?>">
  <?php echo csrf_field(); ?>
  <input type="submit" name="" value="Save">

</form>
<?php endif; ?>
<?php /**PATH /var/www/html/connect/resources/views/user/addedu.blade.php ENDPATH**/ ?>