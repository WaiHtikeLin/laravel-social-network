<?php $__env->startSection('link-to-noti'); ?>
nav-item-active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="col-12 col-md-6 clean-white" id="noti_menu_all">
</div>

<script type="text/javascript">







  function getAllNoti(page=0)
  {
    if(page>0)
      document.querySelector("#load-more-noti").remove();

    $.get('<?php echo e(url('/get/notifications')); ?>/'+page,function(data)
      {
        $("#noti_count_all").html('');

        if(page<1 && data.length==0)
        {
          $("#noti_menu_all").html(`<div class="d-flex vh-100">
          <p class="text-center text-muted align-self-center w-100" style="font-size:2em">No notifications</p>
          </div>`);
          return false;
        }

        $.each(data,function(index, noti) {

          let wrap=document.createElement('div');
          $("#noti_menu_all").append(createNoti(noti,wrap));


        });

        if(data.length==10)
          $("#noti_menu_all").append(createLoadMore(page+1));


      });

  }

  function createLoadMore(page)
  {
    let wrap=document.createElement('p');
    wrap.className="text-center";
    wrap.id="load-more-noti";
    wrap.innerHTML=`<button class="btn btn-light" onclick="getAllNoti(${page})">Load more</button>`;

    return wrap;
  }

  getAllNoti();

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/menu/notifications.blade.php ENDPATH**/ ?>