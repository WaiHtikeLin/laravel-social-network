<?php $__env->startSection('link-to-settings'); ?>
side-nav-active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="col-12 col-md-6 clean-white">

  <?php if(session('status')): ?>

  <div class="alert alert-success alert-dismissible fade show" role="alert">
  <?php echo e(session('status')); ?>

    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>

  <?php endif; ?>

  <p class="text-right"><a href="#" onclick="editSettings(this)">Edit settings</a> </p>
  <form action="<?php echo e(url('/update/settings')); ?>" method="post">
    <?php echo method_field('patch'); ?>
    <?php echo csrf_field(); ?>

    <div class="row mb-3">
      <label class="col-8 col-form-label">Who can see your friends list?</label>
      <div class="col-4">
        <select class="form-select" name="friends_privacy" aria-label="Choose privacy" disabled>
          <option value="onlyme" <?php echo e($friends_privacy['onlyme']); ?>>Only me</option>
          <option value="friend" <?php echo e($friends_privacy['friend']); ?>>Friends</option>
          <option value="public" <?php echo e($friends_privacy['public']); ?>>Public</option>
        </select>
      </div>

    </div>

    <div class="row mb-3">
      <label class="col-8 col-form-label">Who can see your followers list?</label>
      <div class="col-4">
        <select class="form-select" name="followers_privacy" aria-label="Choose privacy" disabled>
          <option value="onlyme" <?php echo e($followers_privacy['onlyme']); ?>>Only me</option>
          <option value="friend" <?php echo e($followers_privacy['friend']); ?>>Friends</option>
          <option value="public" <?php echo e($followers_privacy['public']); ?>>Public</option>
        </select>
      </div>

    </div>

    <div class="row mb-3">
      <label class="col-8 col-form-label">Who can see your following people list?</label>
      <div class="col-4">
        <select class="form-select" name="following_privacy" aria-label="Choose privacy" disabled>
          <option value="onlyme" <?php echo e($following_privacy['onlyme']); ?>>Only me</option>
          <option value="friend" <?php echo e($following_privacy['friend']); ?>>Friends</option>
          <option value="public" <?php echo e($following_privacy['public']); ?>>Public</option>
        </select>
      </div>

    </div>

    <p class="text-center"><input type="submit" class="d-none" value="Update Settings" id="update-settings" /></p>

  </form>

  <p class="mt-5"><a href="<?php echo e(url('/blocked')); ?>">Show blocked people</a></p>
</div>
<script type="text/javascript">
  function editSettings(link)
  {
    event.preventDefault();
    let f=link.parentNode.nextElementSibling;

    f.querySelectorAll('select').forEach(s=>{s.disabled=false;});
    f.querySelector('#update-settings').classList.remove('d-none');
    link.remove();
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/user/settings.blade.php ENDPATH**/ ?>