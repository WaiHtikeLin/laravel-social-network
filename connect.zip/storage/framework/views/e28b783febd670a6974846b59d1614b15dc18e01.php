<?php $__env->startSection('link-to-about'); ?>
nav-item-active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="col-12 d-md-none clean-white">
  <nav class="nav flex-column">
     <a href="<?php echo e(url('')); ?>/myprofile" class="nav-link">
       <img src="<?php echo e(asset('storage/profile_pics/profile.jpeg')); ?>" alt="" style="height:3em;width:3em" class="rounded-circle mr-2">
      <?php echo e(Auth::user()->name); ?></a>
    <a class="nav-link" href="<?php echo e(url('')); ?>/myprofile"><img src="<?php echo e(asset('/img/profile.png')); ?>" alt="" class="side-menu">Profile</a>
     <a class="nav-link" data-toggle="modal" href="#newPost">
       <img src="<?php echo e(asset('/img/plus.png')); ?>" alt="" class="side-menu">
       New Post</a>
     <a class="nav-link" href="#">
       <img src="<?php echo e(asset('/img/lock.png')); ?>" alt="" class="side-menu">
       Private Posts</a>
    <a class="nav-link" href="#"><img src="<?php echo e(asset('/img/heart.png')); ?>" alt="" class="side-menu">Favorites</a>
    <a class="nav-link" href="#"><img src="<?php echo e(asset('/img/settings.png')); ?>" alt="" class="side-menu">Settings</a>

     <a class="nav-link" href="<?php echo e(route('logout')); ?>"
        onclick="event.preventDefault();
                      document.getElementById('logout-form').submit();"><img src="<?php echo e(asset('/img/logout.png')); ?>" alt="" class="side-menu">Logout</a>

    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo csrf_field(); ?>
    </form>

  </nav>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/user/about.blade.php ENDPATH**/ ?>