<?php $__env->startSection('link-to-options'); ?>
nav-item-active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<div class="col-12 col-md-6 clean-white">

  <?php echo $__env->make('components.side-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/user/options.blade.php ENDPATH**/ ?>