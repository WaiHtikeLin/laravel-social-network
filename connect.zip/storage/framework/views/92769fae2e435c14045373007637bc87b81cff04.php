<div class="h-100 d-flex justify-content-center align-items-center">
  <div class="text-center">
    <p>Something went wrong!</p>
    <button class="btn btn-light" id="network-error">Try Again!</button>
  </div>

</div>
<?php /**PATH /var/www/html/connect/resources/views/errors/network.blade.php ENDPATH**/ ?>