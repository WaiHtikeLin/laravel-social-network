<?php $__env->startSection('link-to-home'); ?>
nav-item-active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="col-12 col-md-6" id="feed_<?php echo e($id); ?>">
</div>
<?php echo $__env->make('post.posts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
  fetch('<?php echo e(url("/get/post/$id")); ?>').then(response=>{
    if(response.ok)
      return response.json();
    throw new Error();
  }).then(feed=>{
    document.querySelector('#feed_<?php echo e($id); ?>').append(renderFeed(feed));
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/connect/resources/views/post/singlepost.blade.php ENDPATH**/ ?>