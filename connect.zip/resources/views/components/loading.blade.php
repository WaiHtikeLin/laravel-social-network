<div class="h-100 d-flex justify-content-center align-items-center">
  <div class="spinner-border spinner-border-sm" role="status">
    <span class="sr-only">Loading...</span>
  </div>
</div>
