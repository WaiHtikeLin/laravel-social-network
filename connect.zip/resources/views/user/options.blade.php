@extends('layouts.master')

@section('link-to-options')
nav-item-active
@endsection

@section('main')
<div class="col-12 col-md-6 clean-white">

  @include('components.side-nav')
</div>
