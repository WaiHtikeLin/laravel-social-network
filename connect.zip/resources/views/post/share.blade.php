<a href="{{url('')}}/user/profile/${share.owner.id}"
class="text-decoration-none react-link text-dark">
  <img src="{{ asset('storage/profile_pics/${share.owner.pics[0].name}') }}" alt=""
      style="height:3em;width:3em" class="rounded-circle mr-1">
  <span><strong>${share.owner.name}</strong></span></a>
