@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
          <h3>Terms Of Service</h3>
          <ul>
            <li>We don’t charge you to use Connect or the other products and services covered by these Terms</li>
            <li>We neither sell you data nor analyze your data.</li>
            <li>You give us permission to store your data</li>
          </ul>
        </div>
      </div>
</div>
@endsection
